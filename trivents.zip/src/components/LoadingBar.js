import React from 'react'

const Loading = () => (
  <div className="leftRightLeft" />
)

export default Loading