import "./Event/Event.css"
import React, {useState, useEffect, useContext} from 'react'
import Loading from './LoadingBar'
import Event from './Event'

import 'date-fns';
import DateFnsUtils from '@date-io/date-fns';
import {MuiPickersUtilsProvider, KeyboardDatePicker} from '@material-ui/pickers'

import {Link} from 'react-router-dom';
import timeFunc from '../functions/timeFunctions'
import {SelectedSocsContext} from '../App'

const dateFormat = require('dateformat');
const today = () => new Date(dateFormat( new Date(), "dd mmm yyyy" ))

const defaultFilters = {
  "startDate": today(),
  "searchTerm": "",
}

function Events(props) {

  const [selectedSocs, /*setSelectedSocs*/] = useContext(SelectedSocsContext)
  const [rawEventData, setRawEventData] = useState([]);
  const [events, setEvents] = useState([]);
  const [userEventFilters, setUserEventFilters] = useState( defaultFilters )
  
  const fetchEvents = async () => {
    console.log( "arr ", JSON.stringify([...selectedSocs]) )
    let data

    //optional "VIEW_ALL" element within society IDs
    if (!selectedSocs.has("VIEW_ALL"))
      data = await fetch(window.location.origin + `/api/eventdata?socs=${JSON.stringify([...selectedSocs])}`);
    else 
      data = await fetch(window.location.origin + `/api/eventdata`);
      
    let events    = await data.json()

    if (!events.err & !events.error)
      events = events.map(event => ({
        ...event, 
        date: new Date(event.date), 
        societyNames: JSON.parse(event.societyNames)
      }));

    console.log(events)
    setRawEventData(events)
  }
  
  useEffect(() => {
    fetchEvents()
  }, [] );


  const handleFilterChange = (e) => {
    switch(e.target.name){
      case "searchTerm":
        setUserEventFilters({...userEventFilters, searchTerm: e.target.value })
        break;
      
      case "clearSearch":
        setUserEventFilters( defaultFilters )
        performFilter({resetSearch: true})
        break;

      default:
        break;
    }
    
  }
  
  const handleDateChange = (date) => {
    //update user filters store
    setUserEventFilters({...userEventFilters, startDate: date})

    //update search if date is valid
    if ( timeFunc.isValidDate(date) ) {
      console.log("date is valid : ", date) 
      performFilter({startDate: date})
    }

  }

  //FILTER BY USER SETTINGS
  const performFilter = (inputs = {startDate: null, resetSearch: false}) => {
    //ensure picked date is valid
    if (!timeFunc.isValidDate(inputs.startDate) & !timeFunc.isValidDate(userEventFilters.startDate)) return
    
    //test search speed
    var t0 = performance.now() 

    //filter by date, which may have just been updated and passed in
    let date = (inputs.startDate) ? inputs.startDate : userEventFilters.startDate
    let events = rawEventData.filter(event => (date < event.date))

    //filter by what is in the search bar, unless we have just reset search bar
    if (userEventFilters.searchTerm && !inputs.resetSearch){

      const searchTerm = userEventFilters.searchTerm.toLowerCase()
      
      //we check the title, location and the society names
      events = events.filter(event => {        
        return (
             !!event.title.toLowerCase().match(searchTerm)
          || !!event.location.toLowerCase().match(searchTerm)
          || !!event.societyNames.toString().toLowerCase().match(searchTerm)
        ) 
      }) 
      events.searchTerm = searchTerm
    }

    //conclude speed test
    var t1 = performance.now()
    console.log("Filtering took " + (t1 - t0) + " milliseconds.")

    //return events to state
    console.log(`after filter: ${events.length} events`)
    setEvents(events)
  }

  useEffect(() =>{
    performFilter()
  }, [rawEventData])

  return(
    <div className="card">
      <h1> Events {events.searchTerm ? `- "${events.searchTerm}"` : ""}</h1>

      <div><Link  className="button modernButton" to={"/societies"}> 
        Choose societies 
      </Link></div>      

      <div className="userEventFilters form" style={{display: "block"}}>
          <input placeholder="Search Events..." type="text" name="searchTerm" 
                 value={userEventFilters.searchTerm} 
                 onChange={handleFilterChange}>
          </input>

          <button className="button buttonRound fas fa-search" type="submit" value="&#xf002; Search" onClick={performFilter} 
          style={{margin: "0.5rem", padding:"0.6rem", fontFamily: "Font Awesome 5 Free",  fontSize: "1.3em", fontWeight: 900}}/>
          
          <button className="button buttonRound" name="clearSearchTerm" onClick={handleFilterChange} 
                  style={{transform: "scale(0.8)"}}>
            X Clear
          </button>
      </div>

      <div style={{display: "flex", flexDirection: "row", alignItems: "center", justifyContent: "center"}}>
        <span style={{marginRight: "1rem", marginTop: "1.5rem"}}> Events from: </span>
        
        <MuiPickersUtilsProvider utils={DateFnsUtils}>
          <KeyboardDatePicker
            margin="normal"
            id="date-picker-dialog"
            label="Date picker dialog"
            format="dd/MM/yyyy"
            name="setStartDate"
            value={userEventFilters.startDate}
            onChange={handleDateChange}
            KeyboardButtonProps={{
              'aria-label': 'change date',
            }}
          />
        </MuiPickersUtilsProvider>
        
      </div>

      {(rawEventData & !rawEventData.err & rawEventData.length===0) ? <Loading /> : ""}
      
      <div className="events">

      { rawEventData.err ? 
          "Error: Could not connect" :
        !events.length ? 
          <p style={{textAlign: "center"}}> No events found for after 
            {dateFormat(events.startDate, " dddd dS mmm yyyy")}
            {userEventFilters.searchTerm  ? ` for "${userEventFilters.searchTerm}"` : "" }
            {userEventFilters.searchTerm  ? ` for "${userEventFilters.searchTerm}"` : "" }
            {!selectedSocs.has("VIEW_ALL")? ` for selected societies ` : ""}
          </p>  
        :
        events.map((event, index, arr) => (              
          <div key={`event-div-${index}`}>
              
            {( !index || !timeFunc.datesAreOnSameDay( new Date(arr[index-1].date) , new Date(event.date) ) ) ?   
              <h2 className="dateHeader"> {dateFormat(event.date, "dddd dS mmmm")} </h2> 
            : ""}

            <Event event={event} key={event._id} />
              
          </div>)
        )
      }
      </div>


    </div>
  )
}   

export default Events