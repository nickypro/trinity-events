const scraperApiKeys = [
  "f79012824ed50a850b4daea5f52e7722", //pochinkn@tcd
  "b3847a8ad06fd9aad82d8ba7db3220aa", //pesvut@gmail
  "993feeb85494fc74029aa3d8c829174f", //nicholaspochinkov@gmail
  "aa181aca6da1de684389cf678c4444e5", //yhlmljrurxqiiifdng@awdrt.org
  "a66f99853f48fa7faa7281d900b2a873", //m9qev@inbov03.com
  "6b74d39bdc2eff62b8aa3ab2f4c2500e", //cagem16832@inbov03.com
  "d929f72c07d3a15f4d240de9c4a4413f", //zamauri.sholom@andsee.org
  "6249435075a15e92b1e6f2d97034a079", //erryn.holli@andsee.org
  "5d0b709c43a67f3bb736c049d1149d11", //djibril.jeovanni@andsee.org
  "610bdd9a5170995f9afaa1cd0139fc06", //janah.ryn@andsee.org
  "96a64ec7cfbdc22931cae4f67d2f16de", //breaker.syler@andsee.org
];

module.exports = scraperApiKeys;